## Clock
set_property PACKAGE_PIN AL17 [get_ports clk]
set_property IOSTANDARD LVCMOS12 [get_ports clk]
create_clock -period 10.000 -name clk [get_ports clk]

## LED
set_property PACKAGE_PIN AF5 [get_ports led]
set_property IOSTANDARD LVCMOS12 [get_ports led]